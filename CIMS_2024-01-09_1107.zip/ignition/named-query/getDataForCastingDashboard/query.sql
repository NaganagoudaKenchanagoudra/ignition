SELECT
    DISTINCT o.[production_order] as ProductionOrder
    ,o.[standard_alloy] as StandardAlloy 
    ,o.[sfg_code] as SfgCode
    ,o.[planned_order_qty] as PlannedOrderQty
    ,s.[po_status] as Status
    ,s.[Press] as Press
    ,o.[release_date] as ReleaseDate
    ,castOpr.[Machine] as Machine
FROM [CIMS].[dbo].[mes_orders] o
LEFT JOIN [CIMS].[dbo].[mes_status] s
    ON o.[production_order] = s.[mes_po]
LEFT JOIN [CIMS].[dbo].[mes_casting] castOpr
    ON o.[production_order] = castOpr.[PO]
WHERE s.[po_status] = castOpr.[Status] AND
o.[release_date] >= DATEADD(day, -365, getdate());