# Function to Post when operation completed
def post_SAP_IN(ID,OPRN,PONO,YIELD,TXT,SD,ST,ED,ET,F,MT):
	template={
		  "row":
			{
			      "id": "",
			      "oprn": "",
			      "prod_order": "",
			      "yield": "",
			      "long_text": "",
			      "oprn_start_execution_date": "",
			      "oprn_start_execution_time": "",
			      "oprn_end_execution_date": "",
			      "oprn_end_execution_time": "",
			      "flag": "",
			      "message_type": "",
			      "remarks": "",
			      "mov_type":""
			}
			}				
	#if Yield in negitive value say as 0
	if 	float(YIELD)<=0:
		YIELD=0
	else:
		YIELD=YIELD				
	# Update the values of specific keys as needed
	template["row"]["id"] = int(ID)
	template["row"]["oprn"] = int(OPRN)		
	template["row"]["prod_order"] = PONO
	template["row"]["yield"] = float(YIELD)
	template["row"]["long_text"] = TXT
	template["row"]["oprn_start_execution_date"] = str(SD)
	template["row"]["oprn_start_execution_time"] = ST
	template["row"]["oprn_end_execution_date"] = str(ED)
	template["row"]["oprn_end_execution_time"] = ET		
	template["row"]["flag"] = int(F)
	# Check if MT is Empty
	if MT is None:
		template["row"]["mov_type"] = ""
	else:
		template["row"]["mov_type"] = str(MT)
	# encode dictionary to JSON
	jsonParams = system.util.jsonEncode(template)
	# post to SAP
	#	url='http://jalpodev.jindalaluminium.com:50000/RESTAdapter/CIMSMovementHeader/'template = {
  	url=system.tag.read('[B_IMS]REST_API/REST_Tags/URL2_OperationEntry').value
	Uname=system.tag.read('[B_IMS]REST_API/REST_Tags/UName').value
	Pw=system.tag.read('[B_IMS]REST_API/REST_Tags/UPassword').value	
	postReturn =system.net.httpPost(url,'application/json',postData =jsonParams,username=Uname,password=Pw,connectTimeout=20000,readTimeout =60000,bypassCertValidation=True)
	#Convert received data to dictonary
	RESPONSE=system.util.jsonDecode(postReturn)
#	return jsonParams
#	if Response contains "" say status as Error
	if len(str(RESPONSE))==2:
		STATUS='E'
		#Update the logtable
		API.API_Operation_Entry.update_log_table(int(ID),OPRN,PONO,STATUS,"DATA NA")												 
		#Update the tempgodmov table
		API.API_Operation_Entry.update_temInitialSc_table(int(ID))
		
	else:	
		# Condition to save and acknowledge	
		if MT is not None and 'Document Cancelled' in str(RESPONSE['remarks']):
			STATUS='I'
		elif 'Confirmation Done' in str(RESPONSE['remarks']):
			STATUS='I'
		else:
			STATUS='E'	
		#Update the logtable
		API.API_Operation_Entry.update_log_table(RESPONSE['id'],OPRN,PONO,STATUS,RESPONSE['remarks'])
												 
		#Update the tempgodmov table
		API.API_Operation_Entry.update_temInitialSc_table(RESPONSE['id'])

#	Function to update API log table	
def update_log_table(ID,OPRN,PONO,STATUS,REMARKS):
	query='''
				INSERT INTO [dbo].[API_logs]
				           ([uid]
				           ,[oprn]
				           ,[pono]
				           ,[status]
				           ,[message])
				     VALUES
				           (?,?,?,?,?)
				'''
	args=[int(ID),int(OPRN),str(PONO),str(STATUS),str(REMARKS)]	
	return system.db.runPrepUpdate(query, args, 'CIMS2')	
		
# Function to update the tempInitial_sc table
def update_temInitialSc_table(ID):
	query='''
			UPDATE [dbo].[tempinitialsc]
			   SET [flag] = 1
			 WHERE [uid]=?
				'''
	args=[int(ID)]
	return system.db.runPrepUpdate(query, args, 'CIMS_SAP_IN')	
	
# Check the tempInitialSC table and call the function POST method to SAP
def temp_InitialSC_que_check():
	query='''
			SELECT TOP (1) [oprn]
			      ,trim([prod_order]) as [prod_order]
			      ,[yield]
			      ,trim([long_text]) as [long_text]
			      ,trim([oprn_start_execution_date]) as [oprn_start_execution_date]
			      ,[oprn_start_execution_time]
			      ,trim([oprn_end_execution_date]) as [oprn_end_execution_date]
			      ,[oprn_end_execution_time]
			      ,[flag]
			      ,[uid]
			      ,[mov_type]
			  FROM [INBOUNDCIMS].[dbo].[tempinitialsc]
			  where flag=0
		  '''	
	args=[]
	DATASET=system.db.runPrepQuery(query, args, 'CIMS_SAP_IN')
	if len(DATASET)>=1:
		# Call the POST function 
		ST=system.date.format(DATASET[0]['oprn_start_execution_time'],'hh:mm:ss')
		ET=system.date.format(DATASET[0]['oprn_end_execution_time'],'hh:mm:ss')
		return API.API_Operation_Entry.post_SAP_IN(DATASET[0]['uid'],DATASET[0]['oprn'],DATASET[0]['prod_order'],DATASET[0]['yield'],DATASET[0]['long_text'],DATASET[0]['oprn_start_execution_date'],ST,DATASET[0]['oprn_end_execution_date'],ET,DATASET[0]['flag'],DATASET[0]['mov_type'])
	else:
		return 'Empty'	
	
										