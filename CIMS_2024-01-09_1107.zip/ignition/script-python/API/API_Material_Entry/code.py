# Function to call for IN Operation exists
def post_SAP_IN(ID,OPRN,PONO,MC,MD,MS,QTY,BATCH,SL,F,MT):
	template = {
			    "row": {
			        "id": "",
			        "oprn": "",
			        "prod_order": "",
			        "material_code": "",
			        "material_description": "",
			        "material_selection": "",
			        "qty": "",
			        "qty_uom": "KG",
			        "batch": "",
			        "valuation_type": "",
			        "storage_loc": "",
			        "flag": "",
			        "message_type": "",
			        "remarks": "",
			        "mov_type":""
			    }
			}
	# Update the values of specific keys as needed
	template["row"]["id"] = ID
	template["row"]["oprn"] = OPRN		
	template["row"]["prod_order"] = PONO
	template["row"]["material_code"] = MC
	template["row"]["material_description"] = MD
	template["row"]["material_selection"] = MS
	template["row"]["qty"] = QTY
	template["row"]["batch"] = BATCH
	template["row"]["storage_loc"] = SL		
	template["row"]["flag"] = F
	# Check if MT is Empty
	if MT is None:
		template["row"]["mov_type"] = ""
	else:
		template["row"]["mov_type"] = str(MT)
				
	# encode dictionary to JSON
	jsonParams = system.util.jsonEncode(template)
	# post to SAP
#	url='http://jalpodev.jindalaluminium.com:50000/RESTAdapter/CIMSMovementItem/'
	url=system.tag.read('[B_IMS]REST_API/REST_Tags/URL1_MaterialEntry').value
	Uname=system.tag.read('[B_IMS]REST_API/REST_Tags/UName').value
	Pw=system.tag.read('[B_IMS]REST_API/REST_Tags/UPassword').value
	postReturn =system.net.httpPost(url,'application/json',postData =jsonParams,username=Uname,password=Pw,connectTimeout=20000,readTimeout =60000,bypassCertValidation=True)
	#Convert received data to dictonary
	RESPONSE=system.util.jsonDecode(postReturn)
	
	# Condition to save and acknowledge	
	#Update the logtable
	API.API_Material_Entry.update_log_table(ID,OPRN,PONO,MC,MS,QTY,BATCH,RESPONSE["message_type"],RESPONSE['remarks'])
											 
	#Update the tempgodmov table
	API.API_Material_Entry.update_tempgodmov_table(RESPONSE['id'])
	
	# If error delete the entry in MF&HF table	
	if str(RESPONSE["message_type"])=='E':		
		if MT is None:
			#Delete the entry in MF&HF operation	
			API.API_Material_Entry.delete_entry_MFHF(int(RESPONSE['id']))	
		else:
			pass	
		API.API_Material_Entry.delete_godmov_and_tempgodmov(int(RESPONSE['id']))
		print 'API Failed'	
	else:
		pass 	
		
	return 	RESPONSE

# Function to call if OUT type exists				
def post_SAP_OUT(ID,OPRN,PONO,MC,MD,MS,QTY,VT,SL,F,MT):
	template = {
			    "row": {
			        "id": "",
			        "oprn": "",
			        "prod_order": "",
			        "material_code": "",
			        "material_description": "",
			        "material_selection": "",
			        "qty": "",
			        "qty_uom": "KG",
			        "batch": "",
			        "valuation_type": "",
			        "storage_loc": "",
			        "flag": "",
			        "message_type": "",
			        "remarks": "",
			        "mov_type":""
			    }
			}
	# Update the values of specific keys as needed
	template["row"]["id"] = ID
	template["row"]["oprn"] = OPRN		
	template["row"]["prod_order"] = PONO
	template["row"]["material_code"] = MC
	template["row"]["material_description"] = MD
	template["row"]["material_selection"] = MS
	template["row"]["qty"] = QTY
	template["row"]["valuation_type"] = VT
	template["row"]["storage_loc"] = SL		
	template["row"]["flag"] = F
	# Check if MT is Empty
	if MT is None:
		template["row"]["mov_type"] = ""
	else:
		template["row"]["mov_type"] = str(MT)
		
	# encode dictionary to JSON
	jsonParams = system.util.jsonEncode(template)
	# post to SAP
#	url='http://jalpodev.jindalaluminium.com:50000/RESTAdapter/CIMSMovementItem/'
	url=system.tag.read('[B_IMS]REST_API/REST_Tags/URL1_MaterialEntry').value
	Uname=system.tag.read('[B_IMS]REST_API/REST_Tags/UName').value
	Pw=system.tag.read('[B_IMS]REST_API/REST_Tags/UPassword').value	
	postReturn =system.net.httpPost(url,'application/json',postData =jsonParams,username=Uname,password=Pw,connectTimeout=20000,readTimeout =60000,bypassCertValidation=True)
	#Convert received data to dictonary
	RESPONSE=system.util.jsonDecode(postReturn)
	
	# Condition to save and acknowledge	
	#Update the logtable
	API.API_Material_Entry.update_log_table(ID,OPRN,PONO,MC,MS,QTY,'BATCH',RESPONSE['message_type'],RESPONSE['remarks'])
	
	#Update the tempgodmov table
	API.API_Material_Entry.update_tempgodmov_table(RESPONSE['id'])
	
	# If error delete the entry in MF&HF table	
	if str(RESPONSE['message_type'])=='E':		
		if MT is None:
			#Delete the entry in MF&HF operation	
			API.API_Material_Entry.delete_entry_MFHF(int(RESPONSE['id']))	
		else:
			pass	
		API.API_Material_Entry.delete_godmov_and_tempgodmov(int(RESPONSE['id']))
		print 'API Failed'	
	else:
		pass			
		
# Insert the API logs into the API LOG table in CIMS2 DB
def update_log_table(ID,OPRN,PONO,MC,MS,QTY,BATCH,STATUS,MESSAGE):
	query='''
			INSERT INTO [dbo].[API_logs]
			           ([uid]
			           ,[oprn]
			           ,[pono]
			           ,[material_code]
			           ,[material_selection]
			           ,[batch]
			           ,[qty]
			           ,[qty_uom]
			           ,[status]
			           ,[message])
			     VALUES
			           (?,?,?,?,?,?,?,'KG',?,?)
			'''
	args=[int(ID),int(OPRN),str(PONO),str(MC),str(MS),str(BATCH),float(QTY),str(STATUS),str(MESSAGE)]	
	return system.db.runPrepUpdate(query, args, 'CIMS2')	

# Update the Tempgod table entry using id and flag
def update_tempgodmov_table(ID):
	query='''
			UPDATE [dbo].[tempgoodmov]
			   SET [flag] = 1
			 WHERE [uid]= ?
			'''	
	args=[int(ID)]	
	return system.db.runPrepUpdate(query, args, 'CIMS_SAP_IN')		
	
# Delete the entry in MF&HF operation
def delete_entry_MFHF(ID):	
	query='''
			DELETE FROM [dbo].[mes_MF&HF_operation]
			      WHERE [uid]=?
			'''
	args=[int(ID)]
	return system.db.runPrepUpdate(query, args, 'CIMS2')		
	
# Check the tempGodMov table and call the function POST method to SAP
def temp_GodMov_que_check():
	query='''
			SELECT top (1) [oprn]
			      ,trim([prod_order]) as prod_order
			      ,trim([material_code]) as material_code
			      ,trim([material_description]) as material_description
			      ,trim([material_selection]) as material_selection
			      ,trim([batch]) as batch
			      ,[qty]
			      ,trim([qty_uom]) as qty_uom
			      ,trim([valuation_type]) as valuation_type
			      ,trim([storage_loc]) as storage_loc
			      ,[flag]
			      ,[uid]
			      ,[mov_type]
			  FROM [INBOUNDCIMS].[dbo].[tempgoodmov]
			  where flag=0 and oprn is not null
			'''	
	args=[]
	DATASET=system.db.runPrepQuery(query, args, 'CIMS_SAP_IN')
	# Call the function based on the Material_selection type
	if 	DATASET[0]['material_selection']=='IN':
		return API.API_Material_Entry.post_SAP_IN(DATASET[0]['uid'],DATASET[0]['oprn'],DATASET[0]['prod_order'],DATASET[0]['material_code'],DATASET[0]['material_description'],DATASET[0]['material_selection'],DATASET[0]['qty'],DATASET[0]['batch'],DATASET[0]['storage_loc'],DATASET[0]['flag'],DATASET[0]['mov_type'])
	elif DATASET[0]['material_selection']=='OUT':	
		return API.API_Material_Entry.post_SAP_OUT(DATASET[0]['uid'],DATASET[0]['oprn'],DATASET[0]['prod_order'],DATASET[0]['material_code'],DATASET[0]['material_description'],DATASET[0]['material_selection'],DATASET[0]['qty'],DATASET[0]['valuation_type'],DATASET[0]['storage_loc'],DATASET[0]['flag'],DATASET[0]['mov_type'])		
								
# Delete the entry in godMov and temgodmov using UID	
def delete_godmov_and_tempgodmov(uid):
	query='''
			delete INBOUNDCIMS.dbo.goodmov
			where uid=?
			'''		 
	system.db.runPrepUpdate(query, [uid], 'CIMS_SAP_IN')
	query1='''
			delete INBOUNDCIMS.dbo.tempgoodmov
			where uid=?
			'''	
	try:
		system.db.runPrepUpdate(query1, [uid], 'CIMS_SAP_IN')
	except:
		pass		