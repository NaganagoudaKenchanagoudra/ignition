# Function to POST data into SAP for 04 operation
def post_Endcutt(ID,OPRN,LOGID,PONO,SCRAP,SFG,YIELD,FLAG):
	template={
	    "row":
	{
	      "id": "",
	      "oprn": "",
	      "log_batch_no": "",
	      "prod_order": "",
	      "scrap": "",
	      "sfg_code": "",
	      "yield": "",
	      "qty_uom": "KG",
	      "homog_start_date": "",
	      "homo_start_time": "",
	      "homo_end_date": "",
	      "homo_end_time": "",
	      "flag": "",
	      "message_type": "",
	      "remarks": ""
	}
	}
	# Update the values of specific keys as needed
	template["row"]["id"] = int(ID)
	template["row"]["oprn"] = "0040"		
	template["row"]["log_batch_no"] = LOGID
	template["row"]["prod_order"] = PONO
#	template["row"]["scrap"] = SCRAP
	template["row"]["sfg_code"] = str(SFG)
	template["row"]["yield"] = float(YIELD)	
	template["row"]["flag"] = int(FLAG)
	# encode dictionary to JSON
	jsonParams = system.util.jsonEncode(template)
	# post to SAP
#	url='http://jalpodev.jindalaluminium.com:50000/RESTAdapter/LogEndHomogenizing/'
	url=system.tag.read('[B_IMS]REST_API/REST_Tags/URL3_EH_ENtry').value
	Uname=system.tag.read('[B_IMS]REST_API/REST_Tags/UName').value
	Pw=system.tag.read('[B_IMS]REST_API/REST_Tags/UPassword').value		
	postReturn =system.net.httpPost(url,'application/json',postData =jsonParams,username=Uname,password=Pw,connectTimeout=20000,readTimeout =60000,bypassCertValidation=True)
	#Convert received data to dictonary
	RESPONSE=system.util.jsonDecode(postReturn)
	
	#ADD APILOG Table
#	# Check the Response data and Fainalize the status	
#	if 'Confirmation Done' in str(RESPONSE['remarks']):
#		STATUS='I'
#	else:
	STATUS=RESPONSE['message_type']
	SAPID=RESPONSE['sap_batch_no']
	if len(SAPID)>12:
		SAPID="SAP_ID_NA "
	else:
		pass	
#	Update the SAPID to CIMS table
	query='''
			UPDATE [dbo].[mes_endcut_homogenize_dispatch]
			   SET [sap_batch_no] = trim(?)
			 WHERE [log_batch_no] = ?
			'''	
	args=[SAPID,LOGID]		
	system.db.runPrepUpdate(query, args, 'CIMS2')
	API.API_EH_Operation_Entry.add_log_in_APILOG_table(str(LOGID),str(PONO),int(ID),int(OPRN),STATUS,RESPONSE['remarks'])	
	
	# Update the Entry in tempLogmov table
	API.API_EH_Operation_Entry.update_temlog_table(int(ID))		
	
# Function to POST data into SAP for 05 operation
def post_Homogenization(ID,OPRN,LOGID,PONO,SCRAP,SFG,YIELD,FLAG,SD,ST,ED,ET):
	template={
	    "row":
	{
	      "id": "",
	      "oprn": "",
	      "log_batch_no": "",
	      "prod_order": "",
	      "scrap": "",
	      "sfg_code": "",
	      "yield": "",
	      "qty_uom": "KG",
	      "homog_start_date": "",
	      "homo_start_time": "",
	      "homo_end_date": "",
	      "homo_end_time": "",
	      "flag": "",
	      "message_type": "",
	      "remarks": ""
	}
	}
	# Update the values of specific keys as needed
	template["row"]["id"] = int(ID)
	template["row"]["oprn"] = "0050"		
	template["row"]["log_batch_no"] = LOGID
	template["row"]["prod_order"] = PONO
#	template["row"]["scrap"] = SCRAP
	template["row"]["sfg_code"] = str(SFG)
	template["row"]["yield"] = float(YIELD)	
	template["row"]["flag"] = int(FLAG)
	template["row"]["homog_start_date"] = SD
	template["row"]["homo_start_time"] = ST
	template["row"]["homo_end_date"] = ED
	template["row"]["homo_end_time"] = ET
	# encode dictionary to JSON
	jsonParams = system.util.jsonEncode(template)
	# post to SAP
#	url='http://jalpodev.jindalaluminium.com:50000/RESTAdapter/LogEndHomogenizing/'
	url=system.tag.read('[B_IMS]REST_API/REST_Tags/URL3_EH_ENtry').value
	Uname=system.tag.read('[B_IMS]REST_API/REST_Tags/UName').value
	Pw=system.tag.read('[B_IMS]REST_API/REST_Tags/UPassword').value		
	postReturn =system.net.httpPost(url,'application/json',postData =jsonParams,username=Uname,password=Pw,connectTimeout=20000,readTimeout =60000,bypassCertValidation=True)
	#Convert received data to dictonary
	RESPONSE=system.util.jsonDecode(postReturn)
	
	#ADD APILOG Table
	# Check the Response data and Fainalize the status	
	if 'Confirmation Done' in str(RESPONSE['remarks']):
		STATUS='I'
	else:
		STATUS='E'	
	API.API_EH_Operation_Entry.add_log_in_APILOG_table(str(LOGID),str(PONO),int(ID),int(OPRN),STATUS,RESPONSE['remarks'])	
	
	# Update the Entry in tempLogmov table
	API.API_EH_Operation_Entry.update_temlog_table(int(ID))	
	
	
# Function to add REST API log in API_Log table (CIMS2 DB)
def add_log_in_APILOG_table(LOGID,PONO,UID,OPRN,STATUS,REMARKS):
	query='''
			INSERT INTO [dbo].[API_logs]
			           ([uid]
			           ,[oprn]
			           ,[pono]
			           ,[status]
			           ,[message]
			           ,[logno])
			     VALUES
			           (?,?,TRIM(?),TRIM(?),TRIM(?),TRIM(?))
			'''
	args=[int(UID),int(OPRN),str(PONO),str(STATUS),str(REMARKS),str(LOGID)]	
	return system.db.runPrepUpdate(query, args, 'CIMS2')	
	
# Function to update the entry in templog table
def update_temlog_table(UID):
	query='''
			UPDATE [dbo].[templogmov]
			   SET [flag] = 2
			 WHERE [uid]=? 
			'''
	args=[int(UID)]
	return system.db.runPrepUpdate(query, args, 'CIMS_SAP_IN')
	
# Check the tempLogmov table and start REST API POST call
def Check_que_tempLogmov():
	query='''
			SELECT TOP (1) 
					TRIM([prod_order]) AS [prod_order]
			      ,TRIM([log_batch_no]) AS [log_batch_no]
			      ,TRIM([sfg_code]) AS [sfg_code]
			      ,[scrap]
			      ,[yield]
			      ,[qty_uom]
			      ,TRIM([homog_start_date]) AS [homog_start_date]
			      ,[homog_start_time]
			      ,TRIM([homog_end_date]) AS [homog_end_date]
			      ,[homog_end_time]
			      ,[flag]
			      ,[oprn]
			      ,[uid]
			  FROM [INBOUNDCIMS].[dbo].[templogmov]
			  where flag = 0 or flag = 1
			'''				
	args=[]
	Dataset=system.db.runPrepQuery(query, args, 'CIMS_SAP_IN')
	if len(Dataset)>=1:
		#Check oprn and switch the function for REST POST call
		if(Dataset[0]['oprn'])==40:
			# call End Cutt POST method
#			API.API_EH_Operation_Entry.post_Endcutt(ID,OPRN,LOGID,PONO,SCRAP,SFG,YIELD,FLAG)
			API.API_EH_Operation_Entry.post_Endcutt(Dataset[0]['uid'],Dataset[0]['oprn'],Dataset[0]['log_batch_no'],Dataset[0]['prod_order'],Dataset[0]['scrap'],Dataset[0]['sfg_code'],Dataset[0]['yield'],Dataset[0]['flag'])
			print 'Operation 40'
			
		else:
			# Call Homogenization POST method
#			API.API_EH_Operation_Entry.post_Homogenization(ID,OPRN,LOGID,PONO,SCRAP,SFG,YIELD,FLAG,SD,ST,ED,ET)
			ST=system.date.format(Dataset[0]['homog_start_time'],'hh:mm:ss')
			ET=system.date.format(Dataset[0]['homog_end_time'],'hh:mm:ss')
			API.API_EH_Operation_Entry.post_Homogenization(Dataset[0]['uid'],Dataset[0]['oprn'],Dataset[0]['log_batch_no'],Dataset[0]['prod_order'],Dataset[0]['scrap'],Dataset[0]['sfg_code'],Dataset[0]['yield'],Dataset[0]['flag'],Dataset[0]['homog_start_date'],ST,Dataset[0]['homog_end_date'],ET)
			print 'Operation 40'
	else:
		pass
	return 1													
