def get_Yeild(PONO,OPRN):
	PONO=PONO
	OPNO=int(OPRN)
	InOutQuery='''
				  SELECT DISTINCT [material_selection]
				  FROM [CIMS].[dbo].[mes_MF&HF_operation]
				  WHERE [prod_order]= ? and [oprn]=?
				'''
	InOutArgs=[PONO,OPNO]
	MSelectData=system.db.runPrepQuery(InOutQuery, InOutArgs, 'CIMS2')
	
	if len(MSelectData)==1:
		InQuery='''
					SELECT SUM([qty])
					FROM [CIMS].[dbo].[mes_MF&HF_operation]
					WHERE [prod_order]= ? and [oprn]=? and [material_selection]=?
					'''
		Data=system.db.runPrepQuery(InQuery, [PONO,OPNO,'IN'],'CIMS2')	
		InValue=Data[0][0]	
		return InValue
	else:
		InQuery='''
							SELECT SUM([qty])
							FROM [CIMS].[dbo].[mes_MF&HF_operation]
							WHERE [prod_order]= ? and [oprn]=? and [material_selection]=?
							'''
		try:					
			Data=system.db.runPrepQuery(InQuery, [PONO,OPNO,'IN'],'CIMS2')	
			InValue=Data[0][0]	
			Data1=system.db.runPrepQuery(InQuery, [PONO,OPNO,'OUT'],'CIMS2')
			OutValue=Data1[0][0]
			return float(InValue-OutValue)
		except:
			Data=system.db.runPrepQuery(InQuery, [PONO,OPNO,'IN'],'CIMS2')	
			InValue=Data[0][0]	
			return float(InValue)	