def getPONO(LOGID):
	query='''  select trim([prod_order]) as [prod_order]  FROM [CIMS].[dbo].[mes_endcut_homogenize_dispatch] where log_batch_no=?'''
	DS=system.db.runPrepQuery(query, [LOGID], 'CIMS2')
	return DS[0][0]