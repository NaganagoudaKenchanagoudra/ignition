def onclik_save_Mbutton(E1):
	if E1==1:
		return 'Number 	1'
	else:
		return 'Some other number'	