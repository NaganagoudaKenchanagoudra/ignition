# Update the values from PO1 to PO2 at main,status,Melting, holding and Casting
def Status_transfer_PO1_PO2(PO1,PO2):
	# Get the existing data of PO1 from tables and store in Dataset
	PO2=PO2
	args=[PO1]
	Main_query='''
				SELECT trim([PO]) as PO
				      ,trim(Machine) as Machine
				      ,trim(Status) as Status
				      ,[Date_and_time]
				      FROM cims.dbo.mes_main
				WHERE PO = ?							
				'''
	Main_DS=system.db.runPrepQuery(Main_query, args, 'CIMS2') 
	Status_query='''
					SELECT trim(mes_po) as mes_po
							,trim(Press) as Press
					      ,trim(po_status) as po_status
					      from cims.dbo.mes_status
					      WHERE mes_po = ?
					'''
	Status_DS=system.db.runPrepQuery(Status_query, args, 'CIMS2') 
	Melting_query='''
					SELECT trim(PO) as PO
						  ,Start_Date
						  ,Start_time
						  ,End_Date
						  ,End_time
						  ,Yield
						  ,trim(Machine) as Machine
						  ,trim(Melting_Remark) as Melting_Remark
						  ,trim(status) as status
						  FROM cims.dbo.mes_melting WHERE PO = ?
					'''
	Melting_DS=system.db.runPrepQuery(Melting_query, args, 'CIMS2') 
	Holding_query='''
					SELECT trim(PO) as PO
						  ,Start_Date
						  ,Start_time
						  ,End_Date
						  ,End_time
						  ,Yield
						  ,trim(Machine) as Machine
						  ,trim(Holding_Remark) as Holding_Remark
						  ,trim(status) as status
						  ,trim(Press_derived) as Press_derived
					FROM cims.dbo.mes_holding 
					WHERE PO = ?
					'''
	Holding_DS=system.db.runPrepQuery(Holding_query, args, 'CIMS2') 
	Casting_query='''
					SELECT trim(PO) as PO
					       ,trim(status) as status
					       ,trim(Press_derived) as Press_derived
					       ,trim(Machine) as Machine
					FROM cims.dbo.mes_casting WHERE PO = ?
					'''	
	Casting_DS=	system.db.runPrepQuery(Casting_query, args, 'CIMS2') 
	
	# Update Main,Status,Melting,Holding and Casting table with PO2
	# mes_Main
	U_Main_query='''
				UPDATE cims.dbo.mes_main
				set Machine = ?,
					Status = ?,
					Date_and_time= ?
				WHERE PO = ?							
				'''
	system.db.runPrepUpdate(U_Main_query,[Main_DS[0]['Machine'],Main_DS[0]['Status'],Main_DS[0]['Date_and_time'],PO2],'CIMS2')			
	# mes_status
	U_Status_query='''
				UPDATE cims.dbo.mes_status
				set po_status=?,
					Press=?
				WHERE mes_po = ?						
				'''
	system.db.runPrepUpdate(U_Status_query,[Status_DS[0]['po_status'],Status_DS[0]['Press'],PO2],'CIMS2')			
	# Insert PO2 in mes_melting
	U_Melting_query='''
				INSERT INTO [dbo].[mes_melting]
				           ([PO]
				           ,[Start_Date]
				           ,[Start_time]
				           ,[End_Date]
				           ,[End_time]
				           ,[Yield]
				           ,[Machine]
				           ,[Melting_Remark]
				           ,[Status])
				     VALUES
				           (?,?,?,?,?,?,?,?,?)					
				'''
	U_Melting_query_args=[PO2,Melting_DS[0]['Start_Date'],Melting_DS[0]['Start_time'],Melting_DS[0]['End_Date'],Melting_DS[0]['End_time'],Melting_DS[0]['Yield'],Melting_DS[0]['Machine'],Melting_DS[0]['Melting_Remark'],Melting_DS[0]['Status']]			
	system.db.runPrepUpdate(U_Melting_query,U_Melting_query_args,'CIMS2')			
	# Insert PO2 in mes_Holding
	U_Holding_query='''
				INSERT INTO [dbo].[mes_holding]
				           ([PO]
				           ,[Start_Date]
				           ,[Start_time]
				           ,[End_Date]
				           ,[End_time]
				           ,[Yield]
				           ,[Machine]
				           ,[Holding_Remark]
				           ,[Status])
				     VALUES
				           (?,?,?,?,?,?,?,?,?)					
				'''
	U_Holding_query_args=[PO2,Holding_DS[0]['Start_Date'],Holding_DS[0]['Start_time'],Holding_DS[0]['End_Date'],Holding_DS[0]['End_time'],Holding_DS[0]['Yield'],Holding_DS[0]['Machine'],Holding_DS[0]['Holding_Remark'],Holding_DS[0]['Status']]			
	system.db.runPrepUpdate(U_Holding_query,U_Holding_query_args,'CIMS2')			
	# Insert PO2 in mes_Casting
	U_Castig_query='''
				INSERT INTO [dbo].[mes_casting]
				           ([PO]
				           ,[Press_derived]
				           ,[Machine]				           
				           ,[Status])
				     VALUES
				           (?,?,?,?)					
				'''
	U_Casting_query_args=[PO2,Casting_DS[0]['Press_derived'],Casting_DS[0]['Machine'],Casting_DS[0]['Status']]			
	system.db.runPrepUpdate(U_Castig_query,U_Casting_query_args,'CIMS2')	
	
	# Delete the entries of PO1 in mes_melting,holding and casting table
	D_cast_query='''
					delete [dbo].[mes_casting]
					where PO=?
				'''	
	D_hold_query='''
					delete [dbo].[mes_holding]
					where PO=?
				'''
	D_mel_query='''
					delete [dbo].[mes_melting]
					where PO=?
				'''		
	D_args=[PO1]								
	system.db.runPrepUpdate(D_cast_query, D_args, 'CIMS2')	
	system.db.runPrepUpdate(D_hold_query, D_args, 'CIMS2')	
	system.db.runPrepUpdate(D_mel_query, D_args, 'CIMS2')	
	
	# Update PO1 status in Main and Status tables
	# mes_Main
	U2_Main_query='''
				UPDATE cims.dbo.mes_main
				set Machine = null,
					Status = 'PO Pending'
				WHERE PO = ?							
				'''
	system.db.runPrepUpdate(U2_Main_query,[PO1],'CIMS2')			
	# mes_status
	U2_Status_query='''
				UPDATE cims.dbo.mes_status
				set po_status='PO Pending',
					Press= null
				WHERE mes_po = ?						
				'''
	return system.db.runPrepUpdate(U2_Status_query,[PO1],'CIMS2')			
								