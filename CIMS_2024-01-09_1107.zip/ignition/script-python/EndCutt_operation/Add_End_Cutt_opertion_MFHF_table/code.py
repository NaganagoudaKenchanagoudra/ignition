#Function to Collect LOgID,PO,SFG,Length,dia from Logid as Array
def get_po_sfg(logid):
	query='''
			SELECT TRIM([CIMS].[dbo].[mes_Intermediate_logTable].PO) AS PO, 
	        TRIM([CIMS].[dbo].[mes_orders].sfg_code) AS sfg_code,
	        ([CIMS].[dbo].[mes_Intermediate_logTable].Actual_length) AS Actual_length,
	        [CIMS].[dbo].[mes_orders].log_dia AS dia
			FROM [CIMS].[dbo].[mes_Intermediate_logTable]
			INNER JOIN [CIMS].[dbo].[mes_orders] ON TRIM([CIMS].[dbo].[mes_Intermediate_logTable].PO) = TRIM([CIMS].[dbo].[mes_orders].production_order)
			WHERE TRIM([CIMS].[dbo].[mes_Intermediate_logTable].logid) = ?
			'''
	args=[str(logid)]	
	dataset=system.db.runPrepQuery(query, args, 'CIMS2')	
	return [str(logid),str(dataset[0][0]),str(dataset[0][1]),float(dataset[0][2]),float(dataset[0][3])]

#Funtion to calculate weight based on length and dia input's		
def get_weight(l,d):
	Data=((float(3.14)*float(d)*float(d))/float(4))*(float(l))*(0.0000027)
	# Format the float to display only the last two decimal places
	formatted_float = "{:.2f}".format(Data)
	return float(formatted_float)
	
	
#Fucntion to insert row into scrap into MFHF table	
def add_in_MFHF_CIMS_table(PO,qty,logID,UID):
	query='''
		INSERT INTO [dbo].[mes_MF&HF_operation]
		           ([oprn]
		           ,[prod_order]
		           ,[material_code]
		           ,[material_description]
		           ,[material_selection]
		           ,[batch]
		           ,[qty]
		           ,[qty_uom]
		           ,[valuation_type]
		           ,[storage_loc],[remarks],uid)
		     VALUES
		           (40,?,'1100000006','Aluminium In-House Scrap','OUT','BATCH',?,'KG','RM_SCR_DOM','DA11',?,?)
		'''	
	args=[str(PO),float(qty),str(logID),int(UID)]	
	return system.db.runPrepUpdate(query, args, 'CIMS2')
	
	
#Function to insert row into LogMoov for based on the Endcutt opertaion	
def add_in_loogMov_table(pono,logID,SfgCode,scrap,yeild,UID):
	query='''
		INSERT INTO [dbo].[logmov]
		           ([prod_order]
		           ,[log_batch_no]
		           ,[sfg_code]
		           ,[scrap]
		           ,[yield]
		           ,[qty_uom]
		           ,[flag]
		           ,[oprn]
		           ,uid)
		     VALUES
		           (TRIM(?),TRIM(?),TRIM(?),?,?,TRIM('KG'),0,40,?)
		'''
	args=[str(pono),str(logID),str(SfgCode),float(scrap),float(yeild),UID]		
	return system.db.runPrepUpdate(query, args, 'CIMS_SAP_IN')
	
#Function to add a row in GoodMov table
def addRow_in_GoodMov_table(LOGID,weight,UID):
	query='''
		INSERT INTO [dbo].[goodmov]
		           ([oprn]
		           ,[prod_order]
		           ,[material_code]
		           ,[material_description]
		           ,[material_selection]
		           ,[qty]
		           ,[qty_uom]
		           ,[valuation_type]
		           ,[storage_loc]
		           ,uid)
		     VALUES
		           (40,TRIM(?),TRIM('1100000006'),TRIM('Aluminium In-House Scrap'),TRIM('OUT'),?,TRIM('KG'),TRIM('RM_SCR_DOM'),TRIM('DA11'),?)
		'''	
	args=[LOGID,weight,UID]	
	return system.db.runPrepUpdate(query, args, 'CIMS_SAP_IN')
	
#Function to compile all above function input=(logid,updated length)
def update_endcutt_tables(logID,U_Length):
	#Collect LOgID,PO,SFG,Length,dia from Logid as Array from logID
	LogInfo=EndCutt_operation.Add_End_Cutt_opertion_MFHF_table.get_po_sfg(logID)
	
	UID=system.tag.read('[B_IMS]REST_API/UID_MaterialEntry').value
	UID=UID+1
	LUID=system.tag.read('[B_IMS]REST_API/UID_Oper45').value
	LUID=LUID+1
	#get actual dia and weight before the cutting opertaion
	DIA=LogInfo[4]
	Length=LogInfo[3]
	Weight1=EndCutt_operation.Add_End_Cutt_opertion_MFHF_table.get_weight(Length,DIA)	
	
	#get Weight2 after end cutt opetion
	Length1=U_Length
	Weight2=EndCutt_operation.Add_End_Cutt_opertion_MFHF_table.get_weight(Length1,DIA)	
	
	#get scrap value
	if(Weight1>=Weight2):
		scrap=float(Weight1-Weight2)
	else:
		scrap=float(0)
	
	#Add row in MFHF Table
	EndCutt_operation.Add_End_Cutt_opertion_MFHF_table.add_in_MFHF_CIMS_table(LogInfo[1],scrap,LogInfo[0],UID)	
	
	#Add row in GoodMov Table
	EndCutt_operation.Add_End_Cutt_opertion_MFHF_table.addRow_in_GoodMov_table(LogInfo[1],scrap,UID)
			
	#Add row in LogMoov Table
	EndCutt_operation.Add_End_Cutt_opertion_MFHF_table.add_in_loogMov_table(LogInfo[1],LogInfo[0],LogInfo[2],scrap,Weight2,LUID)	
																																																							
	# Update UID and LUID in Ignition
	system.tag.writeAsync('[B_IMS]REST_API/UID_Oper45', LUID)		
	system.tag.writeAsync('[B_IMS]REST_API/UID_MaterialEntry', UID)	
	
	return 1