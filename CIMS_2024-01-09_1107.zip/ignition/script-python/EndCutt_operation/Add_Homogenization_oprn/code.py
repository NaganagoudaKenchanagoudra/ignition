def update_logid_in_logmoov(SD,ST,ED,ET,LogID):
	query='''
		UPDATE [dbo].[logmov]
		   SET [homog_start_date] = TRIM(?)
		      ,[homog_start_time] = ?
		      ,[homog_end_date] = TRIM(?)
		      ,[homog_end_time] = ?
		      ,[flag] = 1
		      ,[oprn] = 50
		 WHERE [log_batch_no]=?
		'''
	args=[SD,ST,ED,ET,LogID]	
	return system.db.runPrepUpdate(query, args, 'CIMS_SAP_IN')