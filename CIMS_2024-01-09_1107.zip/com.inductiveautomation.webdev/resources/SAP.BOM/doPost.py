def doPost(request, session):
	# take in some JSON data and print it
	# expecting 'names' and 'values' that are of the same length
	 
	# get the incoming parameters
	data = request['postData']
	ID=data['id']
	name = data['name']
	designation = data['area']
	# this will print to the wrapper.log file
	
#	Check wheter entry available wrt srno
	SelectQuery='''
	SELECT *
	FROM [dbo].[rest_test]
	WHERE [srno] = ?
	'''
	SelectArgs=[int(ID)]
	SelectData=system.db.runPrepQuery(SelectQuery, SelectArgs, 'CIMS2')

	if len(SelectData)>=1:
		RETURN= 'Data available in table'
	else:
		# Insert into table
		InsertQueryquery='''
		INSERT INTO [dbo].[rest_test]
		           ([srno]
		           ,[name]
		           ,[designation])
		     VALUES
		           (?,?,?)
		'''
		InsertArgs=[int(ID),str(name),str(designation)]
		system.db.runPrepUpdate(InsertQueryquery, InsertArgs, 'CIMS2')	
		RETURN='Data added successfully in table'
	
	return {'html': RETURN}