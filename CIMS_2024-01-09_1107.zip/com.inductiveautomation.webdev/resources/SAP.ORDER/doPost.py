def doPost(request, session):
	# take in some JSON data and print it
	# get the incoming parameters
	data = request['postData']
	data=data['row']
	ID = data["id"]
#	remarks = data["remarks"]
	prod_order = data["prod_order"]
	material_code = data["material_code"]
	planned_order_qty = data["planned_order_qty"]
	order_qty_unit = data["order_qty_unit"]
	standard_alloy = data["standard_alloy"]
	internal_alloy = data["internal_alloy"]
	log_dia = data["log_dia"]
	log_dia_unit = data["log_dia_unit"]
	log_length = data["log_length"]
	log_length_unit = data["log_length_unit"]
	release_date = data["release_date"]
	status = data["status"]

	
#	Check wheter entry available wrt srno
	SelectQuery='''
	  select *   FROM [OUTBOUNDCIMS].[dbo].[APISAPOrders]
	  	  where id=?
	'''
	SelectArgs=[int(ID)]
	SelectData=system.db.runPrepQuery(SelectQuery, SelectArgs, 'SAPOUTBOUND')
	
	if len(SelectData)>=1:
		RETURN= 'Data available in table'
	else:
		# Insert into table
		InsertQueryquery='''
		INSERT INTO [dbo].[APISAPOrders]
		           ([id]
		           --,[remarks]
		           ,[prod_order]
		           ,[material_code]
		           ,[planned_order_qty]
		           ,[order_qty_unit]
		           ,[standard_alloy]
		           ,[internal_alloy]
		           ,[log_dia]
		           ,[log_dia_unit]
		           ,[log_length]
		           ,[log_length_unit]
		           ,[release_date]
		           ,[status])
	     VALUES
	           (?,?,?,?,?,?,?,?,?,?,?,?,?)
		'''
		InsertArgs=[int(ID),str(prod_order),str(material_code),float(planned_order_qty),str(order_qty_unit),str(standard_alloy),str(internal_alloy),float(log_dia),str(log_dia_unit),float(log_length),str(log_length_unit),str(release_date),str(status)]
		system.db.runPrepUpdate(InsertQueryquery, InsertArgs, 'SAPOUTBOUND')
		RETURN='Data added successfully in table'
	
	return {'html': RETURN}